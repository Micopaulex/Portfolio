# John Mico Paule — Portfolio Website

This folder is ready to publish on Netlify, Vercel, GitHub Pages, or any static web host.

## Entry point
- `index.html`

## Notes
The portfolio page already includes the final contact and LinkedIn links.
Your artwork gallery and profile image are referenced by the page as previously prepared.

## Deploy
Upload this folder as a static site, or drag-and-drop the ZIP to a host that supports static deployment.
